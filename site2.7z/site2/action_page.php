<html>
    <script>
		alert('Usu�rio cadastrado com sucesso!');
		location.href='site.html';
    </script>";
</html>